﻿using System;
using System.Collections.Generic;

namespace _2ND_Mariya_Beznosova
{
    public class ReversiGame : BoardUtils, IGame
    {
        private const int ExitGameCode = -1;
        private const int ToggleHintsCode = -2;
        private const string PlayerTurn = "player";
        private const string ComputerTurn = "computer";
        private const char DefaultTile = ' ';
        private const int Delay = 1000;

        public void StartGame()
        {
            Console.WriteLine("Press Enter to start");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }

            do
            {
                char[][] mainBoard = BoardUtils.InitializeAndResetBoard();
                char playerTile, computerTile;
                MainMenu.EnterPlayerTile(out playerTile, out computerTile);

                bool showHints = false;
                string turn = MainMenu.WhoGoesFirst();

                Console.WriteLine($"The {turn} will go first.");

                PlayGame(mainBoard, playerTile, computerTile, showHints, turn);

                char[][] playerBoard = GetBoardCopy(mainBoard);
                DisplayEndGameResults(playerBoard, playerTile, computerTile);

            } while (MainMenu.PlayAgain());
        }

        private void PlayGame(char[][] mainBoard, char playerTile, char computerTile, bool showHints, string turn)
        {
            do
            {
                switch (turn)
                {
                    case PlayerTurn:
                        HandlePlayerTurn(mainBoard, playerTile, showHints);
                        break;
                    case ComputerTurn:
                        HandleComputerTurn(mainBoard, computerTile);
                        break;
                    default:
                        return;
                }

                Hints.ShowPoints(mainBoard, playerTile, computerTile);

                int[] move = GetPlayerOrComputerMove(mainBoard, playerTile, computerTile, turn);

                if (move[0] == ExitGameCode)
                {
                    Console.WriteLine("Thanks for playing!");
                    return;
                }
                else if (move[0] == ToggleHintsCode)
                {
                    showHints = !showHints;
                    continue;
                }
                else
                {
                    Moves.MakeMove(mainBoard, GetTileForTurn(turn, playerTile, computerTile), move[0], move[1]);
                }

            } while (!HandleTurnEnd(mainBoard, playerTile, computerTile, ref turn));
        }

        private void HandlePlayerTurn(char[][] mainBoard, char playerTile, bool showHints)
        {
            DrawBoard(mainBoard);
            Console.WriteLine("Press Enter to make your move.");
            Console.ReadLine();
            if (showHints)
            {
                Hints.ShowHints(mainBoard, Moves.GetValidMoves(mainBoard, playerTile));
            }
        }

        public void HandleComputerTurn(char[][] mainBoard, char computerTile)
        {
            DrawBoard(mainBoard);
            Console.WriteLine("Computer is thinking...");
            System.Threading.Thread.Sleep(Delay);
        }

        private int[] GetPlayerOrComputerMove(char[][] mainBoard, char playerTile, char computerTile, string turn)
        {
            return turn == PlayerTurn ? Moves.GetPlayerMove(mainBoard, playerTile) : Moves.GetComputerMove(mainBoard, computerTile);
        }

        private char GetTileForTurn(string turn, char playerTile, char computerTile)
        {
            return turn switch
            {
                PlayerTurn => playerTile,
                ComputerTurn => computerTile,
                _ => DefaultTile // Default case
            };
        }

        private bool HandleTurnEnd(char[][] mainBoard, char playerTile, char computerTile, ref string turn)
        {
            List<int[]> playerValidMoves = Moves.GetValidMoves(mainBoard, playerTile);
            List<int[]> computerValidMoves = Moves.GetValidMoves(mainBoard, computerTile);

            if (playerValidMoves.Count == 0 && computerValidMoves.Count == 0)
            {
                return true;
            }
            else
            {
                turn = turn == PlayerTurn ? ComputerTurn : PlayerTurn;
                return false;
            }
        }

        private void DisplayEndGameResults(char[][] mainBoard, char playerTile, char computerTile)
        {
            char[][] newBoard = BoardUtils.InitializeAndResetBoard();
            mainBoard = GetBoardCopy(newBoard);
            DrawBoard(mainBoard);
            System.Threading.Thread.Sleep(Delay);

            Dictionary<char, int> scores = GetScoreOfBoard(mainBoard);
            int playerScore = scores[playerTile];
            int computerScore = scores[computerTile];

            Console.WriteLine($"X scored {playerScore} points. O scored {computerScore} points.");

            if (playerScore > computerScore)
            {
                Console.WriteLine($"You beat the computer by {playerScore - computerScore} points! Congratulations!");
            }
            else if (playerScore < computerScore)
            {
                Console.WriteLine($"You lost. The computer beat you by {computerScore - playerScore} points.");
            }
            else
            {
                Console.WriteLine("The game was a tie!");
            }
        }
    }
}
