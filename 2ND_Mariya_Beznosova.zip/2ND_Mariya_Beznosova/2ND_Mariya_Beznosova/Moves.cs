﻿using System;
using System.Collections.Generic;

namespace _2ND_Mariya_Beznosova
{
    public class Moves
    {
        private const int NoMove = -1;
        private const int ToggleHints = -2;
        private const char PlayerTileX = 'X';
        private const char PlayerTileO = 'O';
        private const int BoardSize = 8;

        public static List<int[]> GetValidMoves(char[][] board, char tile)
        {
            List<int[]> validMoves = new List<int[]>();

            IterateBoard((x, y) =>
            {
                if (BoardUtils.IsValidMove(board, tile, x, y))
                {
                    validMoves.Add(new int[] { x, y });
                }
            });

            return validMoves;
        }

        public static void MakeMove(char[][] board, char tile, int xstart, int ystart)
        {
            List<int[]> tilesToFlip = new List<int[]>();

            if (BoardUtils.IsValidMove(board, tile, xstart, ystart))
            {
                board[xstart][ystart] = tile;

                char otherTile = (tile == PlayerTileX) ? PlayerTileO : PlayerTileX;

                int[][] directions = new int[][]
                {
                    new int[] {0, 1}, new int[] {1, 1}, new int[] {1, 0}, new int[] {1, -1},
                    new int[] {0, -1}, new int[] {-1, -1}, new int[] {-1, 0}, new int[] {-1, 1}
                };

                foreach (int[] direction in directions)
                {
                    FlipTiles(board, tile, xstart, ystart, otherTile, direction, tilesToFlip);
                }

                foreach (int[] tileToFlip in tilesToFlip)
                {
                    board[tileToFlip[0]][tileToFlip[1]] = tile;
                }
            }
        }

        public static int[] GetComputerMove(char[][] board, char computerTile)
        {
            List<int[]> possibleMoves = ShuffleList(GetValidMoves(board, computerTile));

            return GetBestMove(board, computerTile, possibleMoves);
        }

        public static int[] GetPlayerMove(char[][] board, char playerTile)
        {
            int[] move = new int[] { NoMove, NoMove };
            List<int[]> validMoves = GetValidMoves(board, playerTile);

            if (validMoves.Count == 0)
            {
                return new int[] { NoMove, NoMove };
            }

            string moveStr = GetPlayerInput();

            while (true)
            {
                if (moveStr == "quit")
                {
                    return new int[] { NoMove, NoMove };
                }
                else if (moveStr == "hints")
                {
                    return new int[] { ToggleHints, ToggleHints };
                }

                if (TryParseMove(moveStr, move) && BoardUtils.IsValidMove(board, playerTile, move[0], move[1]))
                {
                    break; // Valid move
                }
                else
                {
                    Console.WriteLine("Invalid move. Please try again.");
                }

                moveStr = GetPlayerInput();
            }
            return move;
        }

        private static void IterateBoard(Action<int, int> action)
        {
            for (int x = 0; x < BoardSize; x++)
            {
                for (int y = 0; y < BoardSize; y++)
                {
                    action(x, y);
                }
            }
        }

        private static List<int[]> ShuffleList(List<int[]> list)
        {
            Random rng = new Random();
            int n = list.Count;

            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                int[] value = list[k];
                list[k] = list[n];
                list[n] = value;
            }

            return list;
        }


        private static void FlipTiles(char[][] board, char tile, int x, int y, char otherTile, int[] direction, List<int[]> tilesToFlip)
        {
            int newX = x + direction[0];
            int newY = y + direction[1];

            while (BoardUtils.IsOnBoard(newX, newY) && board[newX][newY] == otherTile)
            {
                newX += direction[0];
                newY += direction[1];
            }

            if (BoardUtils.IsOnBoard(newX, newY) && board[newX][newY] == tile)
            {
                while (newX != x || newY != y)
                {
                    newX -= direction[0];
                    newY -= direction[1];
                    tilesToFlip.Add(new int[] { newX, newY });
                }
            }
        }

        private static int[] GetBestMove(char[][] board, char computerTile, List<int[]> possibleMoves)
        {
            int[] bestMove = new int[] { NoMove, NoMove };
            int bestScore = -1;

            foreach (int[] possibleMove in possibleMoves)
            {
                char[][] dupeBoard = BoardUtils.GetBoardCopy(board);
                MakeMove(dupeBoard, computerTile, possibleMove[0], possibleMove[1]);
                int score = BoardUtils.GetScoreOfBoard(dupeBoard)[computerTile];

                if (score > bestScore)
                {
                    bestMove = possibleMove;
                    bestScore = score;
                }
            }

            return bestMove;
        }

        private static string GetPlayerInput()
        {
            Console.WriteLine("Enter your move ('quit' to end the game, 'hints' to toggle hints): ");
            return Console.ReadLine()?.ToLower() ?? "";
        }

        public static bool TryParseMove(string moveStr, int[] move)
        {
            if (moveStr.Length == 2 && char.IsDigit(moveStr[0]) && char.IsDigit(moveStr[1]))
            {
                move[1] = int.Parse(moveStr[0].ToString()) - 1;
                move[0] = int.Parse(moveStr[1].ToString()) - 1;
                return true;
            }

            Console.WriteLine("Invalid input. Type the y digit (1-8), then the x digit (1-8).");
            return false;
        }
    }
}
