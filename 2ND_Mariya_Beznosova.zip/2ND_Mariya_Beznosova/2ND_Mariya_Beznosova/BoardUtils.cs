﻿using System;
using System.Collections.Generic;

namespace _2ND_Mariya_Beznosova
{
    public class BoardUtils
    {
        private const char EmptyTile = ' ';
        private const char PlayerTileX = 'X';
        private const char PlayerTileO = 'O';
        private const int BoardSize = 8;

        public static char[][] InitializeAndResetBoard()
        {
            char[][] board = new char[BoardSize][];
            for (int i = 0; i < BoardSize; i++)
            {
                board[i] = new char[BoardSize];
                for (int j = 0; j < BoardSize; j++)
                {
                    board[i][j] = EmptyTile;
                }
            }

            int mid = BoardSize / 2;
            board[mid - 1][mid - 1] = PlayerTileX;
            board[mid - 1][mid] = PlayerTileO;
            board[mid][mid - 1] = PlayerTileO;
            board[mid][mid] = PlayerTileX;

            return board;
        }

        public static void DrawBoard(char[][] board)
        {
            string HLINE = "  +---+---+---+---+---+---+---+---+";
            string VLINE = "  |   |   |   |   |   |   |   |   |";

            Console.WriteLine("    1   2   3   4   5   6   7   8");
            Console.WriteLine(HLINE);

            for (int y = 0; y < BoardSize; y++)
            {
                Console.WriteLine(VLINE);
                Console.Write((y + 1) + " ");
                for (int x = 0; x < BoardSize; x++)
                {
                    Console.Write("| " + board[x][y] + " ");
                }
                Console.WriteLine("|");
                Console.WriteLine(VLINE);
                Console.WriteLine(HLINE);
            }
        }

        public static bool IsValidMove(char[][] board, char tile, int xstart, int ystart)
        {
            if (board[xstart][ystart] != EmptyTile || !IsOnBoard(xstart, ystart))
            {
                return false;
            }

            char otherTile = (tile == PlayerTileX) ? PlayerTileO : PlayerTileX;

            int[][] directions = new int[][] {
                new int[] { 0, 1 },
                new int[] { 1, 1 },
                new int[] { 1, 0 },
                new int[] { 1, -1 },
                new int[] { 0, -1 },
                new int[] { -1, -1 },
                new int[] { -1, 0 },
                new int[] { -1, 1 }
            };

            bool isValid = false;

            foreach (int[] direction in directions)
            {
                int x = xstart + direction[0];
                int y = ystart + direction[1];

                bool foundOpponentTile = false;

                while (IsOnBoard(x, y))
                {
                    if (board[x][y] == otherTile)
                    {
                        foundOpponentTile = true;
                    }
                    else if (board[x][y] == tile && foundOpponentTile)
                    {
                        isValid = true;
                        break;
                    }
                    else
                    {
                        break;
                    }

                    x += direction[0];
                    y += direction[1];
                }
            }

            return isValid;
        }

        public static char[][] GetBoardCopy(char[][] board)
        {
            char[][] dupeBoard = new char[BoardSize][];

            for (int x = 0; x < BoardSize; x++)
            {
                dupeBoard[x] = new char[BoardSize];
                for (int y = 0; y < BoardSize; y++)
                {
                    dupeBoard[x][y] = board[x][y];
                }
            }

            return dupeBoard;
        }

        public static bool IsOnCorner(int x, int y)
        {
            return (x == 0 && y == 0) || (x == BoardSize - 1 && y == 0) || (x == 0 && y == BoardSize - 1) || (x == BoardSize - 1 && y == BoardSize - 1);
        }

        public static bool IsOnBoard(int x, int y)
        {
            return x >= 0 && x < BoardSize && y >= 0 && y < BoardSize;
        }

        public static Dictionary<char, int> GetScoreOfBoard(char[][] board)
        {
            int xscore = 0;
            int oscore = 0;

            for (int x = 0; x < BoardSize; x++)
            {
                for (int y = 0; y < BoardSize; y++)
                {
                    if (board[x][y] == PlayerTileX)
                    {
                        xscore++;
                    }
                    else if (board[x][y] == PlayerTileO)
                    {
                        oscore++;
                    }
                }
            }

            return new Dictionary<char, int>
            {
                { PlayerTileX, xscore },
                { PlayerTileO, oscore }
            };
        }
    }
}
