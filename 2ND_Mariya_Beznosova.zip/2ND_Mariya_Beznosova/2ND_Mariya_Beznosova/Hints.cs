﻿using System;
using System.Collections.Generic;

namespace _2ND_Mariya_Beznosova
{
    public class Hints
    {
        public static void ShowHints(char[][] board, List<int[]> validMoves)
        {
            char[][] boardWithHints = ReversiGame.GetBoardCopy(board);

            foreach (var move in validMoves)
            {
                boardWithHints[move[0]][move[1]] = '*';
            }

            ReversiGame.DrawBoard(boardWithHints);
        }

        public static void ShowPoints(char[][] board, char playerTile, char computerTile)
        {
            Dictionary<char, int> scores = ReversiGame.GetScoreOfBoard(board);
            Console.WriteLine("You have " + scores[playerTile] + " points. The computer has " + scores[computerTile] + " points.");
        }

    }
}
