﻿using System;
using System.Collections.Generic;

namespace _2ND_Mariya_Beznosova
{
    internal interface IGame
    {
        void StartGame();
    }
    internal class GameFactory
    {
        public static IGame CreateGame(string gameType)
        {
            switch (gameType.ToLower())
            {
                case "reversi":
                    return new ReversiGame();
                default:
                    throw new ArgumentException($"Unsupported game type: {gameType}");
            }
        }
    }
    class MainMenu
    {
        static void Main(string[] args)
        {
            Console.WriteLine("==================================================");
            Console.WriteLine("              Welcome to Reversi!                 ");

            Console.WriteLine("==================================================");

            IGame game = GameFactory.CreateGame("reversi");
            game.StartGame();
        }
        public static string WhoGoesFirst()
        {
            return (new Random().Next(2) == 0) ? "computer" : "player";
        }

        public static bool PlayAgain(bool defaultChoice = true)
        {
            Console.WriteLine("Do you want to play again? (yes or no)");
            string input = Console.ReadLine().Trim().ToLower();
            if (input.StartsWith("y") || (string.IsNullOrEmpty(input) && defaultChoice))
            {
                return true;
            }
            return false;
        }

        public static void EnterPlayerTile(out char playerTile, out char computerTile)
        {
            playerTile = ' ';
            computerTile = ' ';

            while (playerTile != 'X' && playerTile != 'O')
            {
                Console.WriteLine("Do you want to be X or O?");
                playerTile = char.ToUpper(Console.ReadKey().KeyChar);
                Console.WriteLine();
            }

            computerTile = (playerTile == 'X') ? 'O' : 'X';
        }
    }

    
   
}
