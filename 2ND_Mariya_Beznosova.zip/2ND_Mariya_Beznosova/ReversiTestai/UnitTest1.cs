using _2ND_Mariya_Beznosova;

namespace ReversiTestai
{
    [TestClass]
    public class UnitTest1
    {
        [TestClass]
        public class MovesTests
        {


            [TestMethod]
            public void GetValidMoves_ReturnsCorrectMoves()
            {
                char[][] board = BoardUtils.InitializeAndResetBoard();
                char tile = 'X';

                var validMoves = Moves.GetValidMoves(board, tile);

                Assert.IsNotNull(validMoves);

            }

            

        }
        [TestClass]
        public class ComputerMovesTest
        {
            [TestMethod]
            public void HandleComputerTurn_ValidInput_ReturnsNoExceptions()
            {
                ReversiGame reversiGame = new ReversiGame();
                char[][] mainBoard = BoardUtils.InitializeAndResetBoard();

                try
                {
                    reversiGame.HandleComputerTurn(mainBoard, 'O');
                }
                catch (Exception ex)
                {
                    Assert.Fail($"Exception thrown: {ex.Message}");
                }
                Assert.IsTrue(true); 
            }

        }
        [TestClass]
        public class BoardTests
        {
            [TestMethod]
            public void CorrectScores()
            {
                char[][] board = new char[][]
                {
                new char[] { 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O' },
                new char[] { 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X' },
                new char[] { 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O' },
                new char[] { 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X' },
                new char[] { 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O' },
                new char[] { 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X' },
                new char[] { 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O' },
                new char[] { 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X' },
                };

                var scores = BoardUtils.GetScoreOfBoard(board);


                Assert.AreEqual(32, scores['X'], "Incorrect score for player X.");
                Assert.AreEqual(32, scores['O'], "Incorrect score for player O.");
            }
        
        
        
            [TestMethod]
            public void TestBoardIsFull()
            {
                ReversiGame reversiGame = new ReversiGame();
                char[][] fullBoard = CreateFullBoard();

                bool isFull = IsBoardFull(fullBoard);

                Assert.IsTrue(isFull, "The board should be full.");
            }

            private char[][] CreateFullBoard()
            {
                char[][] fullBoard = new char[8][];
                for (int i = 0; i < 8; i++)
                {
                    fullBoard[i] = new char[8];
                    for (int j = 0; j < 8; j++)
                    {
                        fullBoard[i][j] = 'X'; 
                    }
                }
                return fullBoard;
            }

            private bool IsBoardFull(char[][] board)
            {
                for (int i = 0; i < board.Length; i++)
                {
                    for (int j = 0; j < board[i].Length; j++)
                    {
                        if (board[i][j] == ' ')
                        {
                            return false; 
                        }
                    }
                }
                return true;
            }


        }

       

    }
}