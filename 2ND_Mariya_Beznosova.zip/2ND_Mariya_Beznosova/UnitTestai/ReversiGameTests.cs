﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.IO;

namespace _2ND_Mariya_Beznosova
{
    [TestClass]
    public class ReversiGameTests 
    {
        [TestMethod]
        public void Moves_Check()
        {
            
        }
    }

}
